// declare module '@env' {
//   export const BASE_URL: string;
// }
